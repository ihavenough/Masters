
# Karolina Ochman - 26109551
# Compile and run the C program

gcc projet.c -o projet -llapack -lm              # compile
projet                                           # execute
gcc projet_mono.c -o projet_mono -llapack -lm    # compile
projet_mono                                      # execute